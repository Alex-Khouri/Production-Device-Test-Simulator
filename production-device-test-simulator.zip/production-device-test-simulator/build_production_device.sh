cd C++
make